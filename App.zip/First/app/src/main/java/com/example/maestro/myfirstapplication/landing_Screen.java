package com.example.maestro.myfirstapplication;

import android.os.Bundle;
import android.app.Activity;
import android.widget.ProgressBar;

public class landing_Screen extends Activity {
    ProgressBar progressBar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_landing__screen);

    }

}
